#! bash oh-my-bash.module
PROMPT="\w>>"
