# Xterm plugin

This plugin sets the xterm title for the current directory and the currently running command.
