# goenv plugin

The goenv plugin will configure goenv paths and configure goenv to manage GOROOT and GOHOME.
