#! bash oh-my-bash.module
_omb_util_binary_exists jungle && eval "$(_JUNGLE_COMPLETE=source jungle)"
