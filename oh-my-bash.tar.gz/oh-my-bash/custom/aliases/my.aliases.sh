alias tf="tail -f"

alias qidong=". /opt/conda/etc/profile.d/conda.sh"
alias ca="conda activate"

#alias ssh_software='ssh cngb-software-0-1'
#alias ssh_test='ssh cngb-xcompute-0-12'
#alias ssh_login='ssh cngb-login-0-10'

