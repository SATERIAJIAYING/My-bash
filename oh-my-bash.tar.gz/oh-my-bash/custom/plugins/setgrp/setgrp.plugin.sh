# if no exists
if [ -z ${NEW_GRP+x} ] ; then
    #default
    export NEW_GRP='st_p17z10200n0306'
fi

if [ $(groups | cut -f 1 -d ' ') != $NEW_GRP ] ; then
    newgrp $NEW_GRP
fi

# set group manually

function setgrp()
{
    export NEW_GRP=$1
    newgrp $NEW_GRP
}
