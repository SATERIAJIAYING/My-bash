#!/usr/bin/bash

PM_ID=P17Z10200N0306
HPC_ID=st.q

function Qsub() {

  if [ $# -eq 0 ] || [ $1 = "-h" -o $1 = "--help" -o $1 = "-help" ]
  then
    echo -e "USAGE: Qsub script vf num_proc qname\nEXAMPLE: Qsub ./pipeline.sh 10G 5 pipeline1\nVAR: PM_ID=$PM_ID HPC_ID=$HPC_ID"
    return 0
  fi

  script=$1
  vf=$2
  np=$3
  na=$4

  qsub -cwd -q $HPC_ID -P $PM_ID -l vf=$vf,num_proc=$np -N $na $script
}
