trash_dir=/ldfssz1/ST_HEALTH/P17Z10200N0306/USER/wangchaoxing/.Trash
rm_path=/usr/bin/rm
# 如果~/.Trash目录不存在，则创建它
if [ ! -d $trash_dir ] ; then
    mkdir $trash_dir
fi

# 设置别名以进行各种操作
# alias rm=trash
alias rl=list_trash
alias ur=undelfile

# 列出回收站中的文件和目录
list_trash()
{
    ls -R $trash_dir/$@
}

# 恢复被删除的文件
undelfile()
{
    mv -i $trash_dir/$@ ./
}

# 删除文件或目录并移到回收站，根据大小决定是否压缩
trash()
{
    rmdir=$(date +%y_%m_%d_%H_%M_%S)
    mkdir $trash_dir/$rmdir
    total_size=0
    for file in "$@"; do
        size=$(du -sb "$file" | awk '{print $1}')
        total_size=$((total_size + size))
        mv "$file" $trash_dir/$rmdir
    done

    if [ $total_size -gt 1048576 ]; then
        tar -czvf $trash_dir/$rmdir.tar.gz -C $trash_dir/$rmdir . && \
        $rm_path -rf $trash_dir/$rmdir
    fi
}

# 清理超过48小时的过期文件和压缩文件
cleanup_trash()
{
    current_time=$(date +%s)
    for item in $trash_dir/*; do
        if [ -d "$item" ]; then
            dir_timestamp=$(stat -c %Y "$item")
            time_difference=$((current_time - dir_timestamp))

            if [ $time_difference -gt 172800 ]; then
                $rm_path -rf "$item"
            fi
        elif [ -f "$item" ] && [[ "$item" == *.tar.gz ]]; then
            file_timestamp=$(stat -c %Y "$item")
            time_difference=$((current_time - file_timestamp))

            if [ $time_difference -gt 172800 ]; then
                $rm_path -f "$item"
            fi
        fi
    done
}

# 清空回收站中的所有文件和目录
cleartrash()
{
    read -p "清空回收站？[y/n]" confirm
    [ "$confirm" == 'y' ] || [ "$confirm" == 'Y' ] && $rm_path -rf $trash_dir/*
}

# 在每次运行脚本时自动清理过期的文件和压缩文件
# cleanup_trash
