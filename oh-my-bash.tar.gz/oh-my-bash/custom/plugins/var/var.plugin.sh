export PATH=/ldfssz1/ST_HEALTH/P17Z10200N0306/USER/wangchaoxing/project/sporadic_abortion_2308/software/annovar:$PATH
export PATH=/ldfssz1/ST_HEALTH/P17Z10200N0306/USER/wangchaoxing/software/subread-2.0.6-Linux-x86_64/bin:$PATH
