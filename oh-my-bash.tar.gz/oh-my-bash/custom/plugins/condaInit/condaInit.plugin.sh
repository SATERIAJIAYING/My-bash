
# conda initialize
eval "$(/ldfssz1/ST_HEALTH/P17Z10200N0306/USER/wangchaoxing/software/anaconda3/bin/conda shell.bash hook)"
export PATH=$PATH:/ldfssz1/ST_HEALTH/P17Z10200N0306/USER/wangchaoxing/software/anaconda3/bin

